<?php
/**
 * Template Name: Search Page
 *
 * @package Muvipro
 */

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<style type='text/css'>
	.home-search .gmr-search {
		padding: 0 0 0 0 !important;
	}
	.home-search .gmr-search input[type="text"] {
		color: #111111 !important;
	}
</style>
<div id="primary" class="content-area col-md-12">

	<main id="main" class="site-main" role="main">

		<?php
		while ( have_posts() ) :
			the_post();

			echo '<div class="home-search">';
			do_action( 'gmr_top_searchbutton' );
			echo '</div>';
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> <?php echo muvipro_itemtype_schema( 'CreativeWork' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>

			<div class="gmr-box-content gmr-single">

				<div class="entry-content entry-content-page" <?php echo muvipro_itemprop_schema( 'text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
					<?php
						the_content();
					?>
				</div><!-- .entry-content -->

			</div><!-- .gmr-box-content -->

			</article><!-- #post-## -->
			<?php

		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

</div><!-- #primary -->

<?php

get_footer();
